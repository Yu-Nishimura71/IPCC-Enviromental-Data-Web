const AirQualData = ({ }) => {
    return (
        <div>
            <h2 className="text-center">
                Air Quality Data
            </h2>
            <hr />
        </div>
    )
}

export default AirQualData