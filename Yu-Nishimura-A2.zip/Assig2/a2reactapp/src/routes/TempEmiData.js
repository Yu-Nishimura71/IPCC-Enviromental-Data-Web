const TempEmiData = ({ }) => {
    return (
        <div>
            <h2 className="text-center">
                Temperature & Emission Data
            </h2>
            <hr />
        </div>
    )
}

export default TempEmiData