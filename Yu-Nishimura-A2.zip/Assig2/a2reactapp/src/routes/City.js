const City = ({ }) => {
    return (
        <div>
            <h2 className="text-center">
                City Lists
            </h2>
            <hr />
        </div>
    )
}

export default City